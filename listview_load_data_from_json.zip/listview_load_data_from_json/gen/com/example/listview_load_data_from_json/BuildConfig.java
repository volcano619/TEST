/** Automatically generated file. DO NOT MODIFY */
package com.example.listview_load_data_from_json;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}