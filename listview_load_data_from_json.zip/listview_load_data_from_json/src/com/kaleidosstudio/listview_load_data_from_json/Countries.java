package com.kaleidosstudio.listview_load_data_from_json;

public class Countries {
	String name;
	String code;
}
